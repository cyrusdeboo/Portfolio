<html>
<body>
Welcome: <span style="color: blue"><?php echo $_POST["name"]; ?></span><br><br>
Your email address is: <span style="color: blue"><?php echo $_POST["email"]; ?></span><br><br>
Your date of birth is: <span style="color: blue"><?php echo $_POST["dob"]; ?></span><br><br> 
Tour Package selected : <span style="color: blue"><?php echo $_POST["package"]; ?></span><br><br>
Entertainment Package selected : <span style="color: blue"><?php echo $_POST["party"]; ?></span><br><br>
Discount code applied : <span style="color: blue"><?php echo $_POST["dis_code"]; ?></span><br><br>
Lastly you have also agreed to our terms and conditions.<br><br>
We look forward to seeing you soon. <br>
Thank You<br>
Best Regards<br>
Management of Oxford Travels & Tours

</body>
</html>
