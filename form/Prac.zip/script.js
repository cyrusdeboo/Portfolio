function validateForm() {
  var name = document.forms["myForm"]["name"].value;
  var email = document.forms["myForm"]["email"].value;

  if (name == "") {
    alert("Name must be filled out");
    return false;
  }
 
}

